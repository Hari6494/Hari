import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { ServerComponent } from './server/server.component';
import { SKLogInPageComponent } from './sk-log-in-page/sk-log-in-page.component';
import { warningAlertComponent } from './warning-alert.component/warning-alertComponent';
import { SuccessAlertComponentComponent } from './success-alert-component/success-alert-component.component';


@NgModule({
  declarations: [
    AppComponent,
    ServerComponent,
    SKLogInPageComponent,
    warningAlertComponent,
    SuccessAlertComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
