import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SKLogInPageComponent } from './sk-log-in-page.component';

describe('SKLogInPageComponent', () => {
  let component: SKLogInPageComponent;
  let fixture: ComponentFixture<SKLogInPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SKLogInPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SKLogInPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
