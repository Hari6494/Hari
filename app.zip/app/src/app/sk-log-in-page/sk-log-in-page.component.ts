import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sk-log-in-page',
  templateUrl: './sk-log-in-page.component.html',
  styleUrls: ['./sk-log-in-page.component.css']
})
export class SKLogInPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
