CREATE TABLE [Shk_User] (
  [user_id] int PRIMARY KEY IDENTITY(1, 1),
  [phone_number] int,
  [full_name] nvarchar(255),
  [location_id] int,
  [email_id] nvarchar(255),
  [role_id] int,
  [pure_veg] bool
)
GO

CREATE TABLE [Shk_tables] (
  [table_id] int PRIMARY KEY IDENTITY(1, 1),
  [seat_count] int
)
GO

CREATE TABLE [Shk_hotel] (
  [hotel_id] int PRIMARY KEY IDENTITY(1, 1),
  [hotel_name] nvarchar(255),
  [phone_number] int,
  [location_id] int,
  [table_id] int,
  [pure_veg] bool,
  [dishes_id] int
)
GO

CREATE TABLE [Shk_location] (
  [location_id] int PRIMARY KEY IDENTITY(1, 1),
  [address] nvarchar(255),
  [landmark] nvarchar(255),
  [city] nvarchar(255),
  [state] nvarchar(255),
  [pincode] int
)
GO

CREATE TABLE [Shk_Role] (
  [role_id] int PRIMARY KEY IDENTITY(1, 1),
  [role_name] int
)
GO

CREATE TABLE [Shk_dishes] (
  [dish_id] int PRIMARY KEY IDENTITY(1, 1),
  [dish_name] nvarchar(255),
  [dish_price] int
)
GO

CREATE TABLE [Shk_cart] (
  [user_id] int PRIMARY KEY IDENTITY(1, 1),
  [dish_id] int,
  [quantity] int,
  [favorite_bool] bool
)
GO

CREATE TABLE [Shk_bill] (
  [bill_id] int PRIMARY KEY IDENTITY(1, 1),
  [amount] int,
  [payment_status_id] int,
  [user_id] int
)
GO

CREATE TABLE [Shk_payment_status] (
  [payment_status_id] int PRIMARY KEY IDENTITY(1, 1),
  [payment_type] nvarchar(255),
  [payment_status] int
)
GO

ALTER TABLE [Shk_hotel] ADD FOREIGN KEY ([location_id]) REFERENCES [Shk_location] ([location_id])
GO

ALTER TABLE [Shk_hotel] ADD FOREIGN KEY ([table_id]) REFERENCES [Shk_tables] ([table_id])
GO

ALTER TABLE [Shk_hotel] ADD FOREIGN KEY ([dishes_id]) REFERENCES [Shk_dishes] ([dish_id])
GO

ALTER TABLE [Shk_location] ADD FOREIGN KEY ([location_id]) REFERENCES [Shk_User] ([location_id])
GO

ALTER TABLE [Shk_Role] ADD FOREIGN KEY ([role_id]) REFERENCES [Shk_User] ([role_id])
GO

ALTER TABLE [Shk_cart] ADD FOREIGN KEY ([user_id]) REFERENCES [Shk_User] ([user_id])
GO

ALTER TABLE [Shk_cart] ADD FOREIGN KEY ([dish_id]) REFERENCES [Shk_dishes] ([dish_id])
GO

ALTER TABLE [Shk_bill] ADD FOREIGN KEY ([payment_status_id]) REFERENCES [Shk_payment_status] ([payment_status_id])
GO

ALTER TABLE [Shk_bill] ADD FOREIGN KEY ([user_id]) REFERENCES [Shk_User] ([user_id])
GO
