const http = require ('http');
const debug = require('debug')('node-angular');
const app = require("./Backend/app");

const normalizeport = val=> {
  var port = parseInt(val,10);

  if(isNaN(port)){
    return val;
  }
  if (port>=0){
    return port;
  }
  return false;
};

const onError = error => {
  if (error.syscall != 'listen'){
    throw error;
  }
  const bind = typeof addr ==="string" ?"pipe" + addr : "port"+port;
switch(error.code){
  case "EACCES":
    console.error(bind + " require elevated privilages");
    precces.exit(1);
    break;
    case "EADDRINUSE":
      Console.error(bind + " is already in use");
      process.exit(1);
      break;
    default:
      throw error;
}
};

const onListening = ()=>{
  const addr = server.address();
  const bind = typeof addr === "string" ? "pipe " + addr : "port " + port;
debug ("Listening on " + bind);
};

const port = process.env.PORT || 3000;

app.set('port',port);
const server = http.createServer(app);
server.on("error",onError);
server.on("listening",onListening);

// const server = http.createServer((req,res)=>{
//   res.end('This is my first response');
// });

server.listen(port);
