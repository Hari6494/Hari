const express = require('express');
const bodyParser = require("body-parser");
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));


app.use((req,res,next)=>{
  res.setHeader("Access-Control-Allow-Origin","*");
  res.setheader("Access-Control-Allow-Headers","Origin,x-Requested-with,Content-Type,Accept");
  res.setHeader("Access-Control-Allow-Methods","Get,POST,PATCH,DELETE,OPTIONS");
  next();
});

app.post("/api/post",(req,res,next)=>{
  const post = re.body;
  console.log(post);
  res.status(201).json({
    messgae:'post added successfully'
  });
})

app.use('/api/post',(req,res,next)=>{

  const posts = [
    {
      id :"id1",
      title :'firstt',
      content : 'firstc'
    },
    {
      id :"id2",
      title :'secondt',
      content : 'secondc'
    }
  ];
res.status(200).json({
  messgae : 'posts fetched successfully!',
posts:posts
});
});

module.exports= app;
