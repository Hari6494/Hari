import { Component,EventEmitter, } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'farmfresh';
  items_selected_count_App:number =0;
  onReceiveEvent(EmittedObj){
    this.items_selected_count_App = EmittedObj;
     }
}
