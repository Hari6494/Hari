import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatMenuModule} from '@angular/material/menu';
import {FormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
import {MatIconModule} from '@angular/material/icon'
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatExpansionModule} from '@angular/material/expansion'
import {MatFormFieldModule} from '@angular/material/form-field'
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatDialogModule} from '@angular/material/dialog';
import {MatInputModule} from '@angular/material/input';
import {MatBadgeModule} from '@angular/material/badge';
import {MatCardModule} from '@angular/material/card';
import {MatButtonModule} from '@angular/material/button';
import {MatListModule} from '@angular/material/list';
import {MatDividerModule} from '@angular/material/divider';
import {MatTabsModule} from '@angular/material/tabs';
import {MatTableModule} from '@angular/material/table';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatCheckboxModule} from '@angular/material/checkbox';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FfHeaderComponent,FfLoginPageComponent, DialogOverviewExampleDialog } from './ff-header/ff-header.component';
import { FfFooterComponent } from './ff-footer/ff-footer.component';
import { FfBodyComponent } from './ff-body/ff-body.component';
import { TestComponentComponent } from './test-component/test-component.component';
import { FfSellerComponent } from './ff-body/ff-seller/ff-seller.component';
import { FfBuyerComponent } from './ff-body/ff-buyer/ff-buyer.component';

import { HttpClientModule } from '@angular/common/http';
import { itemService} from './ff-body/ff-body.service'


@NgModule({
  declarations: [
    AppComponent,
    FfHeaderComponent,
    FfFooterComponent,
    FfBodyComponent,
    FfLoginPageComponent,
    DialogOverviewExampleDialog,
    TestComponentComponent,
    FfSellerComponent,
    FfBuyerComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    MatMenuModule,
    FormsModule,
    BrowserAnimationsModule,
    MatIconModule,
    MatToolbarModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    MatDialogModule,
    MatInputModule,
    MatBadgeModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatDividerModule,
    MatTabsModule,
    MatTableModule,
    MatDatepickerModule,
    MatCheckboxModule,
  ],
  providers: [itemService],
  bootstrap: [AppComponent]
})
export class AppModule { }
