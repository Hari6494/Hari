import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FfBodyComponent } from './ff-body.component';

describe('FfBodyComponent', () => {
  let component: FfBodyComponent;
  let fixture: ComponentFixture<FfBodyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FfBodyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FfBodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
