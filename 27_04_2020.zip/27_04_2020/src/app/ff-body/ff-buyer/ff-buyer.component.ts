import { Component, OnInit, ViewChild,Output,EventEmitter} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {SelectionModel} from '@angular/cdk/collections';
import {MatSort} from '@angular/material/sort';
import {CommonModule} from '@angular/common'

import {FF_Item} from '../ff-body.model'


@Component({
  selector: 'app-ff-buyer',
  templateUrl: './ff-buyer.component.html',
  styleUrls: ['./ff-buyer.component.css']
})
export class FfBuyerComponent implements OnInit {
  items_selected_count:number = 0;

  @Output() EventEmitterObj = new EventEmitter();

  Ff_Items:FF_Item[] =[
    new FF_Item('1', 'Mint' , 'Mint' ,1,10,true,10, 'Mint'),
    new FF_Item('2', 'Coriander leaves', 'Coriander leaves',2,20,false,5, 'Coriander leaves'),
    new FF_Item('3', 'Curry Leaves', 'Curry Leaves',3,10,true,10, 'Curry Leaves'),
    new FF_Item('4', 'Fennugreek leaves' , 'Fennugreek leaves' ,4,10,false,5, 'Fennugreek leaves' ),
    new FF_Item('5', 'Amarnath spined' , 'Amarnath spined' ,5,20,true,10, 'Amarnath spined' ),
    new FF_Item('6', 'Agathi leaves' , 'Agathi leaves' ,6,10,false,5, 'Agathi leaves' ),
    new FF_Item('7', 'Amarnath' , 'Amarnath' ,7,10,true,10, 'Amarnath' ),
    new FF_Item('8', 'Sorrel leaves' , 'Sorrel leaves' ,8,20,false,5, 'Sorrel leaves' ),
    new FF_Item('9', 'Drumstick leaves', 'Drumstick leaves',9,10,true,10, 'Drumstick leaves'),
    new FF_Item('10', 'Basil' , 'Basil' ,10,10,false,5, 'Basil' )
];

  ngOnInit(): void {
  }

  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator,{static:true}) paginator: MatPaginator;

  displayedColumns_Available: string[] = ['Item Name','Quantity','Price','Total price'];
  displayedColumns_EditSale: string[] = ['itemId','itemName','itemAvailable','itemPrice'];
  Total_Items_DataSource = new MatTableDataSource(this.Ff_Items);
  selection = new SelectionModel<FF_Item>(true, []);
  Items_For_Sale = this.Ff_Items.filter(item => item.item_available >0);
  Items_Selected_DataSource = new MatTableDataSource(this.Items_For_Sale.filter(item => item.item_selected == true));
  minSaleDate = new Date().getFullYear();
  MaxSaleDate = new Date().getFullYear();

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.Total_Items_DataSource.filter = filterValue.trim().toLowerCase();

    if (this.Total_Items_DataSource.paginator) {
      this.Total_Items_DataSource.paginator.firstPage();
    }
  }

  getTotalCost() {
    return this.Items_For_Sale.filter(item => item.item_selected == true).map(i => (i.item_price * i.item_selected_Count)).reduce((acc:number, value:number) => acc + value, 0);
  }
   constructor() {
    this.Total_Items_DataSource = new MatTableDataSource(this.Ff_Items);
    this.selection = new SelectionModel<FF_Item>(true, []);
    this.Items_For_Sale = this.Ff_Items.filter(item => item.item_available >0);
    this.Items_Selected_DataSource = new MatTableDataSource(this.Items_For_Sale.filter(item => item.item_selected == true));
    this.items_selected_count = this.Items_For_Sale.filter(item => item.item_selected == true).length;
    }

   RefreshTabData()
   {
    this.Items_Selected_DataSource = new MatTableDataSource(this.Items_For_Sale.filter(item => item.item_selected == true));
   };

   EditSelection(){
   this.items_selected_count = this.Items_For_Sale.filter(item => item.item_selected == true).length;
   this.EventEmitterObj.emit(this.items_selected_count);
  }
}
