import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { map } from 'rxjs/operators';

import { FF_Item } from "./ff-body.model";

@Injectable({ providedIn: "root" })
export class itemService {
  private FF_Items: FF_Item[] = [];
  private FF_itemsUpdated = new Subject<FF_Item[]>();

  constructor(private http: HttpClient) {}

  getItems() {
    this.http
      .get<{ message: string; items: any }>(
        "http://localhost:3000/api/posts"
      )
      .pipe(map((itemData) => {
        return itemData.items.map(item => {
          return {
            item_name: item.item_name,
            item_price: item.item_price,
            item_available: item.item_available,
            item_id: item._id
          };
        });
      }))
      .subscribe(transformeditems => {
        this.FF_Items = transformeditems;
        this.FF_itemsUpdated.next([...this.FF_Items]);
      });
  }

  getItemUpdateListener() {
    return this.FF_itemsUpdated.asObservable();
  }

  addItem(item_name: string, item_price: number,item_available:number) {
    console.log("I am in ff-body.server file");
    const item: FF_Item = { item_id: null, item_name: item_name, item_price: item_price,item_available:item_available
  ,item_name_tamil: 'test'
  ,item_img_id: 606
  ,item_selected_Count:0
  ,item_selected:false
  ,item_description: 'test'
  // ,item_sale_date:
    };
    this.http
      .post<{ message: string, postId: string }>("http://localhost:3000/api/posts", item)
      .subscribe(responseData => {
        const id = responseData.postId;
        item.item_id = id;
        this.FF_Items.push(item);
        this.FF_itemsUpdated.next([...this.FF_Items]);
      });
  }

   deletePost(itemId: string) {
    this.http.delete("http://localhost:3000/api/posts/" + itemId)
      .subscribe(() => {
        const updatedItems = this.FF_Items.filter(post => post.item_id !== itemId);
        this.FF_Items = updatedItems;
        this.FF_itemsUpdated.next([...this.FF_Items]);
      });
   }
}
