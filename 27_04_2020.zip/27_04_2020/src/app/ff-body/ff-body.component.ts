import { Component, OnInit, ViewChild, EventEmitter, Output} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {SelectionModel} from '@angular/cdk/collections';
import {MatSort} from '@angular/material/sort';

import {FF_Item} from './ff-body.model'
import { from } from 'rxjs';

minSaleDate: Date;
MaxSaleDate: Date;

export interface Items {
  userId: number;
  checked: Boolean;
  itemId: number;
  itemName: string;
  itemAvailable: number;
  itemPrice: number;
}


const Items_Data: Items[] = [
  {userId: 1,checked: false, itemId: 1,itemName: 'Mint',              itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: true,itemId: 2,itemName: 'Coriander leaves',  itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: false,itemId: 3,itemName: 'Curry Leaves',      itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: true,itemId: 4,itemName: 'Fennugreek leaves', itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: false,itemId: 5,itemName: 'Amarnath spined',   itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: false,itemId: 6,itemName: 'Agathi leaves',     itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: false,itemId: 7,itemName: 'Amarnath',          itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: false,itemId: 8,itemName: 'Sorrel leaves',     itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: false,itemId: 9,itemName: 'Drumstick leaves',  itemAvailable: 10, itemPrice: 10},
  {userId: 1,checked: false,itemId: 10,itemName: 'Basil',            itemAvailable: 10, itemPrice: 10},
];

@Component({
  selector: 'app-ff-body',
  templateUrl: './ff-body.component.html',
  styleUrls: ['./ff-body.component.css']
})
export class FfBodyComponent implements OnInit {
  // panelOpenState = false;
  Ff_Items:FF_Item[] =[
    new FF_Item('1', 'Mint' , 'Mint' ,1,10,true,10, 'Mint'),
    new FF_Item('2', 'Coriander leaves', 'Coriander leaves',2,20,false,5, 'Coriander leaves'),
    new FF_Item('3', 'Curry Leaves', 'Curry Leaves',3,10,true,10, 'Curry Leaves'),
    new FF_Item('4', 'Fennugreek leaves' , 'Fennugreek leaves' ,4,10,false,5, 'Fennugreek leaves' ),
    new FF_Item('5', 'Amarnath spined' , 'Amarnath spined' ,5,20,true,10, 'Amarnath spined' ),
    new FF_Item('6', 'Agathi leaves' , 'Agathi leaves' ,6,10,false,5, 'Agathi leaves' ),
    new FF_Item('7', 'Amarnath' , 'Amarnath' ,7,10,true,10, 'Amarnath' ),
    new FF_Item('8', 'Sorrel leaves' , 'Sorrel leaves' ,8,20,false,5, 'Sorrel leaves' ),
    new FF_Item('9', 'Drumstick leaves', 'Drumstick leaves',9,10,true,10, 'Drumstick leaves'),
    new FF_Item('10', 'Basil' , 'Basil' ,10,10,false,5, 'Basil' )
];

items_selected_count_Body:number =0;
@ViewChild(MatSort, {static: true}) sort: MatSort;
@ViewChild(MatPaginator,{static:true}) paginator: MatPaginator;
@Output() EventEmitterBodyObj = new EventEmitter();

  ngOnInit():void{
    // this.Total_Items_DataSource.paginator = this.paginator;
    // this.Total_Items_DataSource.sort = this.sort;
   };

  displayedColumns_Available: string[] = ['itemName','item_Selected_count','itemPrice'];
  displayedColumns_EditSale: string[] = ['itemId','itemName','itemAvailable','itemPrice'];
  Total_Items_DataSource = new MatTableDataSource(this.Ff_Items);
  selection = new SelectionModel<FF_Item>(true, []);
  Items_For_Sale = this.Ff_Items.filter(item => item.item_available >0);
  Items_Selected_DataSource = new MatTableDataSource(this.Items_For_Sale.filter(item => item.item_selected == true));
  minSaleDate = new Date().getFullYear();
  MaxSaleDate = new Date().getFullYear();

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.Total_Items_DataSource.filter = filterValue.trim().toLowerCase();

    if (this.Total_Items_DataSource.paginator) {
      this.Total_Items_DataSource.paginator.firstPage();
    }
  }

  getTotalCost() {
    return this.Items_For_Sale.filter(item => item.item_selected == true).map(i => i.item_price).reduce((acc:number, value:number) => acc + value, 0);
  }
   constructor() {
    this.Total_Items_DataSource = new MatTableDataSource(this.Ff_Items);
    this.selection = new SelectionModel<FF_Item>(true, []);
    this.Items_For_Sale = this.Ff_Items.filter(item => item.item_available >0);
    this.Items_Selected_DataSource = new MatTableDataSource(this.Items_For_Sale.filter(item => item.item_selected == true));
    }

   RefreshTabData()
   {
    this.Items_Selected_DataSource = new MatTableDataSource(this.Items_For_Sale.filter(item => item.item_selected == true));
   };

   UpdateAvailableCount(event: Event,row?: FF_Item ){
    const UpdatedCount = (event.target as HTMLInputElement);
    row.item_available =Number(UpdatedCount);
    this.Items_For_Sale = this.Total_Items_DataSource.data.filter(item => item.item_available >0);
    this.Items_Selected_DataSource = new MatTableDataSource(this.Items_For_Sale.filter(item => item.item_selected == true));
   }
   onReceiveEvent(EmittedObj: number){
this.items_selected_count_Body = EmittedObj;
this.EventEmitterBodyObj.emit(this.items_selected_count_Body);
 }
}
