export class FF_Item{
public item_id: string;
public item_name:string;
public item_name_tamil:string;
public item_img_id: number;
public item_price:number;
public item_selected:boolean;
public item_selected_Count:number;
public item_available: number;
public item_description: string;
// public item_sale_date : Date;

constructor( item_id:string,
   item_name:string,
   item_name_tamil:string,
   item_img_id:number,
   item_price:number,
   item_selected:boolean,
   item_available: number,
   item_description:string
   )
  {
this.item_id  =  item_id ;
this.item_name  =  item_name ;
this.item_name_tamil  =  item_name_tamil ;
this.item_img_id  =  item_img_id ;
this.item_price  =  item_price ;
this.item_selected  = item_selected ;
this.item_selected_Count =0;
this.item_available  =  item_available ;
this.item_description  =  item_description ;
const current_date = new Date();
// this.item_sale_date = current_date;;
  }
}

export class FF_ItemCart{
  public item_id: number;
  public item_name:string;
  public item_name_tamil:string;
  public item_price:number;
  public item_Amount: number;
  public item_selected:boolean;
  public item_available: number;
  public item_selected_Count: number;
  public item_description: string;
  public item_sale_date : Date;

  constructor( item_id:number,
     item_name:string,
     item_name_tamil:string,
     item_img_id:number,
     item_price:number,
     item_selected:boolean,
     item_available: number,
     item_description:string
     )
    {
  this.item_id  =  item_id ;
  this.item_name  =  item_name ;
  this.item_name_tamil  =  item_name_tamil ;
  this.item_price  =  item_price ;
  this.item_selected  = item_selected ;
  this.item_available  =  item_available ;
  this.item_description  =  item_description ;
  this.item_selected_Count = 1;
  // this.item_Amount =0;
  const current_date = new Date();
  this.item_sale_date = current_date;;
    }
  }
