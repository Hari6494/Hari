const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose")
const app = express();
const Item =  require("./items");


mongoose.connect(
  "mongodb+srv://FF_Admin:sj9SuktP6UTYUA5F@cluster0-qxbk7.gcp.mongodb.net/test?retryWrites=true"
)
.then(()=>{
  console.log("Connected to database!");
})
.catch(()=>{
  console.log("Connection failed");
})

app.use(bodyParser.json);
app.use(bodyParser.urlencoded({extended:false}));

app.use((req,res,next)=>{
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PATCH, DELETE, OPTIONS"
  );
  next();
});

app.post("/api/posts", (req, res, next) => {
  console.log("reached app.post function..");
  const item = new Item({
     item_name: req.body.item_name
    ,item_price: req.body.item_price
    ,item_available:req.body.item_available
    ,item_name_tamil: req.body.item_name_tamil
    ,item_img_id: req.body.item_img_id
    ,item_selected_Count:req.body.item_selected_Count
    ,item_selected:req.body.item_selected
    ,item_description: req.body.item_description
  });
  item.save().then(createdItem => {
    res.status(201).json({
      message: "Item added successfully",
      itemId: createdItem._id
    });
  });
});


  app.get("/api/posts", (req, res, next) => {
      res.find().then(documents=>{
        res.status(200).json({
        message: "Items fetched successfully!",
        items: documents
      });
    });
  });

  app.delete("/api/posts/:id", (req, res, next) => {
    Post.deleteOne({ _id: req.params.id }).then(result => {
      console.log(result);
      res.status(200).json({ message: "Item deleted!" });
    });
  });

  module.exports= app;

  // app.use('/api/post',(req,res,next)=>{
//   const posts = [
//     {
//       id :"id1",
//       title :'firstt',
//       content : 'firstc'
//     },
//     {
//       id :"id2",
//       title :'secondt',
//       content : 'secondc'
//     }
//   ];
// res.status(200).json({
//   messgae : 'posts fetched successfully!',
// posts:posts
// });
// });
