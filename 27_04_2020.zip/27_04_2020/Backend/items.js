const mongoose = require('mongoose');

const item_schema = mongoose.Schema({
  item_id: { type: Number, required: true },
  item_name: { type: String, required: true },
  item_name_tamil: { type: String, required: true },
  item_img_id: { type: Number, required: true },
  item_price: { type: Number, required: true },
  item_selected: { type: Boolean, required: true },
  item_selected_Count: { type: Number, required: true },
  item_available: { type: Number, required: true },
  item_description: { type: String, required: true },
  item_sale_date: { type: Date, required: true }
});

module.exports = mongoose.model('Item', item_schema);

