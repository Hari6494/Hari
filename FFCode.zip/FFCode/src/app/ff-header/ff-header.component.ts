import { Component, OnInit,Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-ff-header',
  templateUrl: './ff-header.component.html',
  styleUrls: ['./ff-header.component.css']
})
export class FfHeaderComponent implements OnInit {

  animal: string;
  name: string;

 //constructor() { }
  openDialog(): void {
    const dialogRef = this.dialog.open(FfLoginPageComponent, {
      width: '250px',
      data: {name: this.name, animal: this.animal}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
    // Open function for Login page
   // openLogInDialog():void{}
  }
  constructor(public dialog: MatDialog) {}

  ngOnInit(): void {
  }
}

export interface DialogData {
  animal: string;
  name: string;
}

export class DialogOverviewExample {

}



@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'dialog-overview-example-dialog.html',
})
export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

}

// login page componnents
@Component({
  selector: 'app-ff-login-page',
  templateUrl: './ff-login-page.component.html',
})
export class FfLoginPageComponent {

  constructor(
    public dialogRef: MatDialogRef<FfLoginPageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

}
