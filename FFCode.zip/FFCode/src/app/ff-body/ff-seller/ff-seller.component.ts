import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ff-seller',
  templateUrl: './ff-seller.component.html',
  styleUrls: ['./ff-seller.component.css']
})
export class FfSellerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
