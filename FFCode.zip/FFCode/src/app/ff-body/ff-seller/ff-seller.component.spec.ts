import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FfSellerComponent } from './ff-seller.component';

describe('FfSellerComponent', () => {
  let component: FfSellerComponent;
  let fixture: ComponentFixture<FfSellerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FfSellerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FfSellerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
