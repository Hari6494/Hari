import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ff-buyer',
  templateUrl: './ff-buyer.component.html',
  styleUrls: ['./ff-buyer.component.css']
})
export class FfBuyerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
