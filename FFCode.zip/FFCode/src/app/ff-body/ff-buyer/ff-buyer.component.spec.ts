import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FfBuyerComponent } from './ff-buyer.component';

describe('FfBuyerComponent', () => {
  let component: FfBuyerComponent;
  let fixture: ComponentFixture<FfBuyerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FfBuyerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FfBuyerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
