import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ff-footer',
  templateUrl: './ff-footer.component.html',
  styleUrls: ['./ff-footer.component.css']
})
export class FfFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
