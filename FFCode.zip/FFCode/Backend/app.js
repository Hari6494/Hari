const express = require('express');
const app = express();

app.use('/api/post',(req,res,next)=>{

  const posts = [
    {
      id :"id1",
      title :'firstt',
      content : 'firstc'
    },
    {
      id :"id2",
      title :'secondt',
      content : 'secondc'
    }
  ];
res.status(200).json({
  messgae : 'posts fetched successfully!',
posts:posts
});
});

module.exports= app;
